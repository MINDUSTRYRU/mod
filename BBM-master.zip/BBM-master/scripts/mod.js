var mod = Vars.mods.locateMod("[purple]better-blocks[white]-mod");
var x = mod.meta;
x.displayName = "[purple]Better-Blocks[white]-Mod";
x.description = "Версия мода для игры на сервере [#008000]Mindustry.ru[#FF484D]:7777\n\n[#ffffff]--------------\n\n[#6F83CB]Discord: [#ffffff][ [#EAB515]https://discord.mindustry.ru [#ffffff]]\n\n--------------\n\n[#0080C0]Developers:\n\n[#ffffff]- [#AC1EF0]Mindustry.ru [#ffffff]([red]Head Developer[#ffffff])\n\n- MemFaceGo [#ffffff]([gold]First Developer[#ffffff]) ";
x.author = "Mindustry.ru";
