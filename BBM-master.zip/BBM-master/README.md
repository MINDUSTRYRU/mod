![Logo](sprites/ReadMe/Logo.gif)

# Better-Blocks-Mod
# Mod Mindustry v6.0
<details> 
  <summary>ENG Description</summary>
Better-Blocks-Mod: This mod adds more blocks, materials and enemies (In development).

The mod is developed specifically for mindustry.ru

For all questions, write to Discord: https://discord.mindustry.ru/
![Discord Shield](https://discordapp.com/api/guilds/658670734222163989/widget.png?style=shield)

Also, everyone can contribute to the development of the mod!
This mod will operate on our server.
The server connection addresses are on the website: https://mindustry.ru/
</details>

<details> 
  <summary>RUS Description</summary>
Better-Blocks-Mod: Этот мод добавляет больше блоков, материалов и врагов(В разаработке).

Мод разрабатывается специально для mindustry.ru

По всем вопросам пишите в Discord: https://discord.mindustry.ru/
![Discord Shield](https://discordapp.com/api/guilds/658670734222163989/widget.png?style=shield)

Так же все желающие могут внести вклад в развитие мода!
Этот мод будет действовать у нас на сервере.
Адреса подключения к серверам находятся на сайте: https://mindustry.ru/
</details>


# Developers

- [MindustryRu](https://github.com/MindustryRu) (Head Developer)
- [MemFaceGo](https://github.com/MemFaceGo) (First Developer)


# Discord Server Banner

<a href="https://discord.mindustry.ru/"><img src="https://discordapp.com/api/guilds/658670734222163989/widget.png?style=banner4" alt="Discord Banner 4"/></a>