![Logo](sprites/ReadMe/Better-Blocks_Mod.png)

# Better-Blocks-Mod

<details> 
  <summary>ENG Description</summary>
Better-Blocks-Mod: this mod adds more blocks , materials and enemies.

The mod is being developed specifically for mindustry.ru.

For all questions, write to Discord: https://discord.mindustry.ru/
![Discord Shield](https://discordapp.com/api/guilds/658670734222163989/widget.png?style=shield)
</details>

<details> 
  <summary>RUS Description</summary>
Better-Blocks-Mod: Этот мод добавляет больше блоков, материалов и врагов.


Мод разрабатывается специально для mindustry.ru.

По всем вопросам пишите в Discord: https://discord.mindustry.ru/
![Discord Shield](https://discordapp.com/api/guilds/658670734222163989/widget.png?style=shield)
</details>

<details> 
  <summary>All blocks of this mod</summary>
   
   #Conveyors
   
![alt text](sprites/ReadMe/Conveyors.png "Conveyors") 

   #Drill
   
![alt text](sprites/ReadMe/Drill.png "Drill") 

   #Energy
   
![alt text](sprites/ReadMe/Energy.png "Energy") 

   #Factories
   
![alt text](sprites/ReadMe/Factories.png "Factories") 

   #Proector&Storage
   
![alt text](sprites/ReadMe/Proector&Storage.png "Proector&Storage") 

   #Reconstructor
   
![alt text](sprites/ReadMe/Reconstructor.png "Reconstructor") 

   #Turrets
   
![alt text](sprites/ReadMe/Turrets.png "Turrets") 

   #Walls
   
![alt text](sprites/ReadMe/Walls.png "Walls")  
</details>


# Translators
- [MemFaceGo](https://github.com/MemFaceGo) (Russian - Owner)
- [MINDUSTRYRU](https://github.com/MINDUSTRYRU) (First Developer)

# Discord Server

<a href="https://discord.mindustry.ru/"><img src="https://discordapp.com/api/guilds/658670734222163989/widget.png?style=banner4" alt="Discord Banner 4"/></a>